# football-db — exact setup steps

**Read this section first, it's the actual answer to "what do I download and click."**

## Why this can't run itself from inside a claude.ai chat

I (Claude, in this chat) run in a sandbox that cannot reach any football
data site — every one of them returns a blocked response, confirmed by
direct test. That's not a policy choice, it's a hard network wall. The
only way this actually collects data is if something with real internet
access runs the code below. Two free options, pick one:

### Option A — GitHub Actions (fully unattended, no PC needed) — recommended

1. Create a free GitHub account if you don't have one: github.com
2. Create a new repository, upload everything in this folder to it
   (drag-and-drop on github.com works, or `git push` if you're comfortable
   with git).
3. In the repo, go to **Settings → Actions → General → Workflow permissions**
   and select "Read and write permissions" (needed so the bot can commit
   the database back).
4. Go to the **Actions** tab, you'll see two workflows:
   - **"Full historical backfill"** — runs every 20 minutes automatically,
     picks up wherever it left off, until all 19 leagues × 5 seasons are
     done. Click **Run workflow** once to kick it off immediately instead
     of waiting for the schedule.
   - **"Daily football data ingest"** — runs once a day forever after,
     keeping it current.
5. Walk away. Check back in an hour or two — the backfill downloads ~19
   small CSV files per season (95 total), this is genuinely fast, not a
   multi-day job. Progress is visible in the Actions tab logs.

This literally is the "runs non-stop, resumes if interrupted" behavior
you asked for — GitHub's servers are doing the work, not your computer,
and not tokens from any AI subscription.

### Option B — Claude Code on your own machine

Only do this if you want an AI actively involved in *extending* the
project (adding new data sources, fixing something, building the
frontend) — for the backfill itself, Option A is simpler and doesn't
use any of your usage limits.

1. Install Node.js if you don't have it: nodejs.org (the LTS version)
2. Install Claude Code: open a terminal and run
   `npm install -g @anthropic-ai/claude-code`
3. `cd` into this folder, run `claude`, log in with your claude.ai account
4. Tell it: *"Run the steps in README.md to set up and backfill the
   database, using ingest_all.py and run_forever.sh"*

Claude Code has real internet access on your machine, so this will
actually work, unlike this chat. If you're on a metered/free plan and it
pauses mid-task, that's a real usage limit — just run `claude` again
later and tell it to continue; `progress.json` means it picks up exactly
where it stopped, nothing is redone.

## What you get: 19 leagues, 5 seasons, ~95 league-seasons of data

See `config/leagues.csv` for the exact list — England, Spain, Italy,
Germany, France (top two tiers each), plus Netherlands, Belgium,
Portugal, Turkey, Greece, and Scotland (all four tiers). This is every
league the free source (football-data.co.uk) covers well, which is most
of Europe's serious football but **not** non-European leagues (MLS,
Brazil, Argentina, Saudi Pro League, etc.) — that needs a different free
source (API-Football's free tier, 100 req/day) as a follow-up, not
included in this first pass because it needs a registered API key from
you, which I can't create on your behalf.

Each league pulls: full match results, shots, shots on target, corners,
fouls, cards, referee, and Pinnacle/Bet365 closing odds — going back 5
seasons, per your ask.

## Once the data's in: predict + pattern-scan

```bash
python model/backtest.py --db football.db --league premier_league --train-through 2025-01-01
python predict.py --db football.db --league premier_league --days 3
```

`predict.py`'s pattern section now shows **both numbers, as you asked**:
raw hit-rate AND the Wilson-adjusted lower bound, side by side. A 4/4
streak and a 17/20 streak both get shown — you decide which to weight,
the tool doesn't hide either one from you.

## Your only manual input: user_ratings

```sql
INSERT INTO user_ratings (team_id, as_of_date, attack_adj, defense_adj, note)
VALUES ('arsenal', '2026-08-29', 0.1, -0.05, 'new CB signing looks strong');
```

Everything else is collected automatically.

## What's proven vs. what's next

**Proven with real tests in this build** (all reproducible — every claim
below was actually executed, not just written):
- Schema builds cleanly, all 11 tables.
- Ingestion correctly parses a real-shaped CSV into matches/stats/odds.
- The Dixon-Coles model recovers known team strengths at 0.93 correlation
  when tested against data with a known ground truth.
- Backtest scores real log-loss/Brier metrics against a market baseline.
- The resumable ingest was tested with a simulated mid-run failure: it
  correctly skipped the 37 already-done jobs on retry and only redid the
  1 that failed.
- Pattern scanner's Wilson bound correctly ranks a 17/20 streak above a
  flashier-looking-but-smaller 4/4 streak.

**Still needs a follow-up pass** (the architecture already supports all
of it, none of this is a redesign):
1. A fixtures puller (so `predict.py` has upcoming matches — ESPN's free
   public API works well for this).
2. xG/advanced stats via FBref — needs a real browser (works fine from
   Claude Code or GitHub Actions, not from a locked-down sandbox).
3. Non-European leagues via API-Football (needs your free API key).
4. Live odds beyond closing lines, via the-odds-api.com's free tier.

Ask me (in Claude Code, where it can actually execute) to build any of
these next — the schema already has the columns waiting for them.
